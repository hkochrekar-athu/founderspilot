import { readFileSync, writeFileSync } from "fs";
import path from "path";

const dataDir = path.join(process.cwd(), "data");

function readJSON(file: string) {
  return JSON.parse(readFileSync(path.join(dataDir, file), "utf-8"));
}

function writeJSON(file: string, data: unknown) {
  writeFileSync(path.join(dataDir, file), JSON.stringify(data, null, 2));
}

export function getClients() { return readJSON("clients.json"); }
export function getTasks() { return readJSON("tasks.json"); }
export function getIncome() { return readJSON("income.json"); }

export function saveClients(data: unknown) { writeJSON("clients.json", data); }
export function saveTasks(data: unknown) { writeJSON("tasks.json", data); }
export function saveIncome(data: unknown) { writeJSON("income.json", data); }

export function getAllData() {
  return {
    clients: getClients(),
    tasks: getTasks(),
    income: getIncome(),
  };
}
