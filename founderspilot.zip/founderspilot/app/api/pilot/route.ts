import { NextRequest, NextResponse } from "next/server";
import { getAllData } from "@/lib/data";

export async function POST(req: NextRequest) {
  try {
    const { message } = await req.json();
    const { clients, tasks, income } = getAllData();

    const systemPrompt = `You are FoundersPilot, an AI operating system for Harshada — a solo founder running Harshada Solutions, a digital agency in Goa, India.

CURRENT CLIENT DATA:
${JSON.stringify(clients, null, 2)}

CURRENT TASKS:
${JSON.stringify(tasks, null, 2)}

INCOME LOG:
${JSON.stringify(income, null, 2)}

TODAY'S DATE: ${new Date().toISOString().split("T")[0]}

You have access to all of Harshada's business data above. Answer questions, surface insights, draft messages, flag risks. Be direct and specific — use actual names, numbers, and dates from the data. Keep responses concise but complete. When asked to draft a message, produce ready-to-send copy.

If asked to add or update data, respond with a JSON action block at the END of your response in this exact format (no extra text after it):
<action>{"type":"add_task","text":"task text","client":"client name or null","priority":"high|medium|low"}</action>
or
<action>{"type":"add_income","client":"name","amount":number,"note":"note","date":"YYYY-MM-DD","incomeType":"payment|pending"}</action>
or
<action>{"type":"update_client","clientId":number,"nextAction":"new next action","lastContact":"YYYY-MM-DD"}</action>`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: "user", content: message }],
      }),
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || "Sorry, something went wrong.";

    // Parse action
    const actionMatch = text.match(/<action>(.*?)<\/action>/s);
    let action = null;
    if (actionMatch) {
      try { action = JSON.parse(actionMatch[1]); } catch {}
    }
    const cleanText = text.replace(/<action>.*?<\/action>/s, "").trim();

    return NextResponse.json({ text: cleanText, action });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ text: "Server error. Check your API key in Vercel env vars.", action: null }, { status: 500 });
  }
}
