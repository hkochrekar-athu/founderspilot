import { NextRequest, NextResponse } from "next/server";
import {
  getClients, getTasks, getIncome,
  saveClients, saveTasks, saveIncome,
} from "@/lib/data";

export async function GET() {
  return NextResponse.json({
    clients: getClients(),
    tasks: getTasks(),
    income: getIncome(),
  });
}

export async function POST(req: NextRequest) {
  const { type, payload } = await req.json();

  if (type === "add_task") {
    const tasks = getTasks();
    tasks.push({ id: Date.now(), ...payload });
    saveTasks(tasks);
    return NextResponse.json({ ok: true, tasks });
  }

  if (type === "toggle_task") {
    const tasks = getTasks();
    const updated = tasks.map((t: { id: number; done: boolean }) =>
      t.id === payload.id ? { ...t, done: !t.done } : t
    );
    saveTasks(updated);
    return NextResponse.json({ ok: true, tasks: updated });
  }

  if (type === "add_income") {
    const income = getIncome();
    income.push({ id: Date.now(), ...payload });
    saveIncome(income);
    return NextResponse.json({ ok: true, income });
  }

  if (type === "update_client") {
    const clients = getClients();
    const updated = clients.map((c: { id: number }) =>
      c.id === payload.clientId
        ? { ...c, nextAction: payload.nextAction, lastContact: payload.lastContact }
        : c
    );
    saveClients(updated);
    return NextResponse.json({ ok: true, clients: updated });
  }

  return NextResponse.json({ ok: false, error: "Unknown type" }, { status: 400 });
}
