"use client";
import { useState, useRef, useEffect, useCallback } from "react";

// ── Types ──────────────────────────────────────────────────────────────────────
type Client = { id: number; name: string; status: string; lastContact: string; nextAction: string; amount: number; paid: number; tags: string[] };
type Task = { id: number; text: string; client: string | null; done: boolean; priority: string };
type Income = { id: number; client: string; amount: number; date: string; type: string; note: string };
type Message = { role: "user" | "assistant"; content: string };

// ── Helpers ────────────────────────────────────────────────────────────────────
function daysSince(dateStr: string) {
  return Math.floor((new Date().getTime() - new Date(dateStr).getTime()) / 86400000);
}
function formatINR(n: number) {
  return "₹" + Number(n).toLocaleString("en-IN");
}
function statusColor(s: string) {
  if (s === "active") return "#22d3a5";
  if (s === "cold") return "#f87171";
  if (s === "prospect") return "#fbbf24";
  return "#94a3b8";
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function Pill({ label, color }: { label: string; color: string }) {
  return (
    <span style={{ background: color + "18", color, border: `1px solid ${color}40`, borderRadius: 99, fontSize: 10, padding: "2px 8px", fontFamily: "monospace", fontWeight: 600, letterSpacing: 1 }}>
      {label.toUpperCase()}
    </span>
  );
}

function ClientCard({ client }: { client: Client }) {
  const days = daysSince(client.lastContact);
  const outstanding = client.amount - client.paid;
  return (
    <div style={{ background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12, padding: "16px 18px", transition: "border-color 0.2s" }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = statusColor(client.status) + "60")}
      onMouseLeave={e => (e.currentTarget.style.borderColor = "#1e2d42")}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div>
          <div style={{ fontWeight: 700, color: "#e2e8f0", fontSize: 14, marginBottom: 4 }}>{client.name}</div>
          <Pill label={client.status} color={statusColor(client.status)} />
        </div>
        {days > 30 && <span style={{ fontSize: 18 }}>⚠️</span>}
      </div>
      <div style={{ fontSize: 12, color: "#64748b", marginBottom: 8 }}>
        Last contact: <span style={{ color: days > 30 ? "#f87171" : "#94a3b8" }}>{days}d ago</span>
      </div>
      <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 10, lineHeight: 1.5 }}>→ {client.nextAction}</div>
      {client.amount > 0 && (
        <div style={{ display: "flex", gap: 12, borderTop: "1px solid #1e2d42", paddingTop: 10 }}>
          {[["TOTAL", client.amount, "#22d3a5"], ["PAID", client.paid, "#94a3b8"], ...(outstanding > 0 ? [["OWED", outstanding, "#fbbf24"]] : [])].map(([l, v, c]) => (
            <div key={l as string}>
              <div style={{ fontSize: 10, color: "#475569", fontFamily: "monospace" }}>{l as string}</div>
              <div style={{ fontSize: 13, color: c as string, fontWeight: 700 }}>{formatINR(v as number)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function TaskItem({ task, onToggle }: { task: Task; onToggle: (id: number) => void }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 0", borderBottom: "1px solid #0f1e30", opacity: task.done ? 0.45 : 1 }}>
      <button onClick={() => onToggle(task.id)} style={{ width: 18, height: 18, borderRadius: 4, border: `2px solid ${task.done ? "#22d3a5" : "#2a3f57"}`, background: task.done ? "#22d3a5" : "transparent", cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
        {task.done && <span style={{ color: "#0a0f1a", fontSize: 11, fontWeight: 900 }}>✓</span>}
      </button>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, color: task.done ? "#475569" : "#cbd5e1", textDecoration: task.done ? "line-through" : "none" }}>{task.text}</div>
        {task.client && <div style={{ fontSize: 11, color: "#475569", marginTop: 2 }}>{task.client}</div>}
      </div>
      <span style={{ fontSize: 10, fontFamily: "monospace", fontWeight: 700, color: task.priority === "high" ? "#f87171" : task.priority === "medium" ? "#fbbf24" : "#64748b" }}>
        {task.priority.toUpperCase()}
      </span>
    </div>
  );
}

function IncomePanel({ income }: { income: Income[] }) {
  const paid = income.filter(i => i.type === "payment").reduce((s, i) => s + i.amount, 0);
  const pending = income.filter(i => i.type === "pending").reduce((s, i) => s + i.amount, 0);
  const total = paid + pending;
  const pct = total > 0 ? Math.round((paid / total) * 100) : 0;
  return (
    <div>
      <div style={{ background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12, padding: "18px 20px", marginBottom: 12 }}>
        <div style={{ fontSize: 11, fontFamily: "monospace", color: "#475569", letterSpacing: 1, marginBottom: 14 }}>INCOME OVERVIEW</div>
        <div style={{ display: "flex", gap: 24, marginBottom: 16, flexWrap: "wrap" }}>
          {[["COLLECTED", paid, "#22d3a5"], ["PENDING", pending, "#fbbf24"], ["TOTAL PIPELINE", total, "#94a3b8"]].map(([l, v, c]) => (
            <div key={l as string}>
              <div style={{ fontSize: 10, fontFamily: "monospace", color: "#475569" }}>{l as string}</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: c as string, letterSpacing: -0.5 }}>{formatINR(v as number)}</div>
            </div>
          ))}
        </div>
        <div style={{ height: 6, background: "#1e2d42", borderRadius: 99, overflow: "hidden" }}>
          <div style={{ width: pct + "%", height: "100%", background: "linear-gradient(90deg,#22d3a5,#0ea5e9)", borderRadius: 99, transition: "width 1s ease" }} />
        </div>
        <div style={{ fontSize: 11, color: "#475569", marginTop: 6, fontFamily: "monospace" }}>{pct}% collected</div>
      </div>
      <div style={{ background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12, overflow: "hidden" }}>
        <div style={{ padding: "12px 16px", borderBottom: "1px solid #1e2d42", fontSize: 11, fontFamily: "monospace", color: "#475569" }}>TRANSACTION LOG</div>
        {income.map(item => (
          <div key={item.id} style={{ display: "flex", alignItems: "center", padding: "12px 16px", borderBottom: "1px solid #0f1e30", gap: 12 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", flexShrink: 0, background: item.type === "payment" ? "#22d3a5" : "#fbbf24" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: "#cbd5e1", fontWeight: 600 }}>{item.client}</div>
              <div style={{ fontSize: 11, color: "#475569" }}>{item.note}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: item.type === "payment" ? "#22d3a5" : "#fbbf24", fontFamily: "monospace" }}>{formatINR(item.amount)}</div>
              <div style={{ fontSize: 11, color: "#475569" }}>{item.date}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ChatMessage({ msg }: { msg: Message }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ display: "flex", justifyContent: isUser ? "flex-end" : "flex-start", marginBottom: 14 }}>
      {!isUser && (
        <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#22d3a5,#0ea5e9)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0, marginRight: 8, alignSelf: "flex-end" }}>✦</div>
      )}
      <div style={{ maxWidth: "80%", padding: "10px 14px", borderRadius: isUser ? "16px 16px 4px 16px" : "16px 16px 16px 4px", background: isUser ? "linear-gradient(135deg,#0ea5e9,#22d3a5)" : "#0f1623", border: isUser ? "none" : "1px solid #1e2d42", color: isUser ? "#0a0f1a" : "#cbd5e1", fontSize: 13, lineHeight: 1.6, fontWeight: isUser ? 600 : 400, whiteSpace: "pre-wrap" }}>
        {msg.content}
      </div>
    </div>
  );
}

// ── Main Dashboard ─────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [tab, setTab] = useState("command");
  const [clients, setClients] = useState<Client[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [income, setIncome] = useState<Income[]>([]);
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hey Harshada 👋 I'm FoundersPilot — I know your clients, your tasks, and your money. Ask me anything.\n\nTry: \"Who needs a follow-up?\" or \"What's my outstanding income?\" or \"Draft a check-in for Venky.\"" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const loadData = useCallback(async () => {
    try {
      const res = await fetch("/api/data");
      const d = await res.json();
      setClients(d.clients);
      setTasks(d.tasks);
      setIncome(d.income);
    } catch {}
    setDataLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const activeClients = clients.filter(c => c.status === "active").length;
  const overdueClients = clients.filter(c => daysSince(c.lastContact) > 30).length;
  const pendingTasks = tasks.filter(t => !t.done).length;
  const totalOutstanding = clients.reduce((s, c) => s + (c.amount - c.paid), 0);

  async function handleSend() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);
    try {
      const res = await fetch("/api/pilot", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: userMsg }) });
      const { text, action } = await res.json();
      setMessages(prev => [...prev, { role: "assistant", content: text }]);
      if (action) {
        if (action.type === "add_task") {
          await fetch("/api/data", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "add_task", payload: { text: action.text, client: action.client, done: false, priority: action.priority || "medium" } }) });
        } else if (action.type === "add_income") {
          await fetch("/api/data", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "add_income", payload: { client: action.client, amount: action.amount, note: action.note, date: action.date, type: action.incomeType } }) });
        } else if (action.type === "update_client") {
          await fetch("/api/data", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "update_client", payload: { clientId: action.clientId, nextAction: action.nextAction, lastContact: action.lastContact } }) });
        }
        await loadData();
      }
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection error — check server logs." }]);
    }
    setLoading(false);
  }

  async function handleToggleTask(id: number) {
    await fetch("/api/data", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "toggle_task", payload: { id } }) });
    await loadData();
  }

  const TABS = [
    { id: "command", label: "✦ Command" },
    { id: "clients", label: "◈ Clients" },
    { id: "tasks", label: "◻ Tasks" },
    { id: "income", label: "₹ Income" },
  ];

  const QUICK_PROMPTS = ["Who needs follow-up?", "What's my income this month?", "Draft check-in for Venky", "What are my top tasks?"];

  if (dataLoading) return (
    <div style={{ minHeight: "100vh", background: "#080d14", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ color: "#22d3a5", fontFamily: "monospace", fontSize: 14, letterSpacing: 2 }}>LOADING...</div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#080d14", fontFamily: "'DM Sans', 'Segoe UI', sans-serif", color: "#e2e8f0" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1e2d42; border-radius: 99px; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        .fade-in { animation: fadeIn 0.3s ease forwards; }
        button { font-family: inherit; }
        textarea { font-family: inherit; }
      `}</style>

      {/* Header */}
      <div style={{ borderBottom: "1px solid #1e2d42", padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#080d14", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 9, background: "linear-gradient(135deg,#22d3a5,#0ea5e9)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>✦</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 16, letterSpacing: -0.3 }}>FoundersPilot</div>
            <div style={{ fontSize: 10, fontFamily: "monospace", color: "#475569" }}>HARSHADA SOLUTIONS · GOA</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 16 }}>
          {[
            { val: activeClients, label: "ACTIVE", color: "#22d3a5" },
            { val: overdueClients, label: "OVERDUE", color: "#f87171" },
            { val: pendingTasks, label: "TASKS", color: "#fbbf24" },
            { val: formatINR(totalOutstanding), label: "OWED", color: "#94a3b8" },
          ].map(s => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: s.color, fontFamily: "monospace" }}>{s.val}</div>
              <div style={{ fontSize: 9, color: "#475569", fontFamily: "monospace", letterSpacing: 0.5 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #1e2d42", padding: "0 24px", background: "#080d14", gap: 4 }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "12px 16px", fontSize: 13, fontWeight: tab === t.id ? 700 : 500, color: tab === t.id ? "#22d3a5" : "#475569", background: "transparent", border: "none", borderBottom: `2px solid ${tab === t.id ? "#22d3a5" : "transparent"}`, cursor: "pointer", transition: "all 0.2s", marginBottom: -1 }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ maxWidth: 900, margin: "0 auto", padding: "24px" }}>

        {/* COMMAND */}
        {tab === "command" && (
          <div className="fade-in" style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 170px)" }}>
            <div style={{ flex: 1, overflowY: "auto", paddingBottom: 16 }}>
              {messages.map((m, i) => <ChatMessage key={i} msg={m} />)}
              {loading && (
                <div style={{ display: "flex", gap: 8, padding: "10px 0", alignItems: "center" }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#22d3a5,#0ea5e9)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>✦</div>
                  {[0, 1, 2].map(i => (
                    <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: "#22d3a5", animation: `pulse 1.2s ${i * 0.2}s infinite` }} />
                  ))}
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
              {QUICK_PROMPTS.map(p => (
                <button key={p} onClick={() => setInput(p)} style={{ padding: "5px 12px", borderRadius: 99, border: "1px solid #1e2d42", background: "transparent", color: "#64748b", fontSize: 11, cursor: "pointer", fontFamily: "monospace", transition: "all 0.2s" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = "#22d3a5"; (e.currentTarget as HTMLButtonElement).style.color = "#22d3a5"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = "#1e2d42"; (e.currentTarget as HTMLButtonElement).style.color = "#64748b"; }}>
                  {p}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
              <textarea value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder="Ask anything about your business…" rows={2}
                style={{ flex: 1, background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12, padding: "12px 16px", color: "#e2e8f0", fontSize: 13, resize: "none", lineHeight: 1.5, transition: "border-color 0.2s", outline: "none" }}
                onFocus={e => (e.target.style.borderColor = "#22d3a5")}
                onBlur={e => (e.target.style.borderColor = "#1e2d42")} />
              <button onClick={handleSend} disabled={loading || !input.trim()} style={{ width: 44, height: 44, borderRadius: 12, border: "none", background: loading || !input.trim() ? "#1e2d42" : "linear-gradient(135deg,#22d3a5,#0ea5e9)", color: loading || !input.trim() ? "#475569" : "#0a0f1a", cursor: loading || !input.trim() ? "not-allowed" : "pointer", fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontWeight: 700 }}>↑</button>
            </div>
          </div>
        )}

        {/* CLIENTS */}
        {tab === "clients" && (
          <div className="fade-in">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <h2 style={{ fontSize: 18, fontWeight: 800 }}>Clients <span style={{ color: "#475569", fontWeight: 400, fontSize: 14 }}>({clients.length})</span></h2>
              <div style={{ display: "flex", gap: 8 }}>
                {["active", "cold", "prospect"].map(s => <Pill key={s} label={s} color={statusColor(s)} />)}
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 12 }}>
              {clients.map(c => <ClientCard key={c.id} client={c} />)}
            </div>
          </div>
        )}

        {/* TASKS */}
        {tab === "tasks" && (
          <div className="fade-in">
            <div style={{ marginBottom: 20 }}>
              <h2 style={{ fontSize: 18, fontWeight: 800 }}>Tasks <span style={{ color: "#475569", fontWeight: 400, fontSize: 14 }}>({tasks.filter(t => !t.done).length} pending)</span></h2>
            </div>
            <div style={{ background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12, padding: "8px 16px", marginBottom: 12 }}>
              {tasks.map(t => <TaskItem key={t.id} task={t} onToggle={handleToggleTask} />)}
            </div>
            <div style={{ padding: "12px 16px", background: "#0f1623", border: "1px solid #1e2d42", borderRadius: 12 }}>
              <div style={{ fontSize: 11, color: "#475569", fontFamily: "monospace", marginBottom: 6 }}>ADD VIA COMMAND</div>
              <div style={{ fontSize: 12, color: "#64748b" }}>Go to Command tab → <span style={{ color: "#22d3a5" }}>"Add a task to send proposal to Zapier lead, high priority"</span></div>
            </div>
          </div>
        )}

        {/* INCOME */}
        {tab === "income" && (
          <div className="fade-in">
            <IncomePanel income={income} />
          </div>
        )}
      </div>
    </div>
  );
}
