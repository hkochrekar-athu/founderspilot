# FoundersPilot 🚀

**AI Operating System for Solo Founders**

> One dashboard. One AI. Knows your clients, your money, your tasks, your follow-ups.

Built for the [AI Agent Olympics Hackathon](https://lablab.ai) · May 2026  
by [Harshada Solutions](https://harshadasolutions.com) · Goa, India

---

## The Problem

Solo founders carry everything in their heads — client names, unpaid invoices, follow-up dates, pending tasks. There's no single place that knows your whole business and can answer *"what do I need to do right now?"*

## The Solution

FoundersPilot is an AI-powered business OS that knows your clients, income, and tasks — and lets you talk to all of it in plain English.

**Ask it anything:**
- *"Who needs a follow-up?"*
- *"What's my outstanding income this month?"*
- *"Draft a check-in message for Venky Customs"*
- *"Add a task to send the proposal to the Zapier lead, high priority"*

The AI reads your live data, reasons across it, and can even update your records through conversation.

## Features

- **Command Agent** — Natural language interface to your entire business
- **Client Tracker** — Status, last contact, next action, outstanding payments
- **Task Manager** — AI-addable tasks with priority levels
- **Income Dashboard** — Pipeline overview, collected vs pending, transaction log
- **Action Loop** — AI responses can trigger real data updates (add task, log payment, update client)

## Tech Stack

- **Next.js 14** — App Router, server components
- **Claude Sonnet** (Anthropic) — The AI brain
- **Vercel** — Deployment
- **JSON flat files** — Simple, portable data layer

## Run Locally

```bash
git clone https://github.com/hkochrekar-athu/founderspilot
cd founderspilot
npm install
cp .env.example .env.local
# Add your ANTHROPIC_API_KEY to .env.local
npm run dev
```

## Deploy to Vercel

1. Import repo to Vercel
2. Add `ANTHROPIC_API_KEY` to Environment Variables
3. Deploy

---

Built by **Harshada Kochrekar** · Harshada Solutions · Goa, India  
*"Goa to the World"*
